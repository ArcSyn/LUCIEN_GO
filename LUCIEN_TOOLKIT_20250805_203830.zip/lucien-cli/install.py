#!/usr/bin/env python3
"""
🔧 LUCIEN CLI INSTALLER
Automated installation and setup script
"""

import subprocess
import sys
import os
from pathlib import Path

def main():
    print("🚀 Lucien CLI Installer")
    print("=" * 50)
    
    # Check Python version
    if sys.version_info < (3, 11):
        print("❌ Python 3.11+ required")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    
    print("✅ Python version check passed")
    
    # Install requirements
    print("📦 Installing dependencies...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], 
                      check=True, capture_output=True)
        print("✅ Dependencies installed successfully")
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        sys.exit(1)
    
    # Run system tests
    print("🧪 Running system tests...")
    try:
        result = subprocess.run([sys.executable, "cli/main.py", "--test", "interactive"], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ System tests passed")
        else:
            print("⚠️ Some tests failed, but installation can continue")
            print(result.stderr)
    except Exception as e:
        print(f"⚠️ Could not run tests: {e}")
    
    # Setup complete
    print("🎉 Installation Complete!")
    print()
    print("🎯 Quick Start:")
    print(f"   python cli/main.py interactive")
    print()
    print("📖 Full documentation: QUICKSTART.md")
    print("🆘 Need help? Run: python cli/main.py --help")

if __name__ == "__main__":
    main()
