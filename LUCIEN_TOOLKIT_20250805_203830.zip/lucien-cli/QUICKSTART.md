# 🚀 LUCIEN CLI QUICKSTART

Welcome to Lucien CLI - The AI-enhanced command-line interface!

## ⚡ Quick Installation

### Prerequisites
- Python 3.11 or higher

### Install Steps

1. **Extract the bundle**
   ```bash
   # Extract LUCIEN_TOOLKIT.zip to your desired location
   unzip LUCIEN_TOOLKIT.zip
   cd lucien-cli
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Test installation**
   ```bash
   python cli/main.py --help
   ```

4. **Run system tests**
   ```bash
   python cli/main.py --test interactive
   ```

## 🎮 First Run Experience

### Interactive Shell Mode
```bash
# Start Lucien in interactive shell mode
python cli/main.py interactive

# Test safe mode
python cli/main.py --safe interactive
```

## 🔒 Production Safety

### Safe Mode
```bash
# Run in safe mode (blocks dangerous commands)
python cli/main.py --safe interactive
```

### Safety Features
- Dangerous command detection and blocking
- File system operation monitoring  
- Comprehensive logging
- Confirmation prompts for destructive actions

## 🆘 Troubleshooting

### Common Issues

**"Module not found" errors**
```bash
pip install -r requirements.txt
```

**Permission errors**
```bash
# On Unix systems
chmod +x cli/main.py
```

### Get Help
```bash
python cli/main.py --help           # General help
python cli/main.py interactive      # Start interactive mode
```

## 🚀 Ready to Start?

```bash
# Start your journey
python cli/main.py interactive

# Experience the AI-enhanced command line
```

---

**Lucien CLI - Where Intelligence Meets Command Line**

*The command-line interface that adapts to you.*
